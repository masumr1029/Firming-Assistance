<?php
    require_once('functions/function.php');

    if(isset($_POST['Send'])){
   
    $name=$_POST['Name'];
    $comment=$_POST['Comment'];
    
    if(empty($name)||(empty($comment))){
      echo"<script>window.alert('please fill up the required fields!!')</script>";
      exit();
      }
    else{
    $insert="INSERT INTO complain(Name,complain)VALUES('$name','$comment')";
    $qry=mysqli_query($con,$insert);
    if($qry){
       echo "Submit succesfully";
      }
      else{
         echo"window.alert('Product insert Failed!!')";
        }
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script defer src="fontawesome-all.js"></script>
	<script defer src="fa-v4-shims.js"></script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="homepage.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="homepage.php" class="nav-link">Home</a>
          </li>

          <li class="nav-item">
            <a href="tips.php" class="nav-link">Firming Tips</a>
          </li>
          <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain</a>
          </li>

          <li class="nav-item">
           <a href="contact2.php" class="nav-link" >Contact</a>
          </li>
      </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
      <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
      
    </ul>
  </div>
  </nav>
  <div class="jumbotron jumbotron-fluid ">
  <div class="container ">

    <form method="post">
      <div class="form-group row">
      <label for="inputEmail3" class="mx-2 col-form-label">Name</label>
      <div class="col-sm-5">
        <input type="text" name="Name" class="form-control mx-5" id="inputEmail3" placeholder="">
      </div>
    </div>
    <div class="form-group row">
      <label for="inputEmail3"  class="mx-2 col-form-label">Comment</label>
      <div class="col-sm-5">
       <textarea class=" py-3 mx-3 form-control" name="Comment"></textarea>
      </div>
    </div>
      <div class="input-group  col-md-6 ">
     <button type="submit" class="btn btn-info ml-auto " name="Send">Post</button>
  </div>
    
    </form>
    
</div>
  
</div>

<footer class="text-muted">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      <p>New to Firming Assistant?</p>
      <a href="#">Get Started..</a>
    </div>
  </footer>
<script type="js/bootstrap.min.js"></script>
</body>
</html>