<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script defer src="fontawesome-all.js"></script>
	<script defer src="fa-v4-shims.js"></script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	<a href="index.php" class="navbar-brand">
		<i class="fab fa-accusoft"></i>
		Firming Assistant
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar">
  	<ul class="navbar-nav">
  		<li class="nav-item">
  			<a href="index.php" class="nav-link">Home</a>
  		</li>
  		<li class="nav-item">
  			<a href="about.php" class="nav-link">About Us</a>
  		</li>
  		<li class="nav-item">
  			<a href="contact.php" class="nav-link">Contact</a>
  		</li>
  		
  	</ul>
  	<ul class="navbar-nav ml-auto">
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-facebook"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-twitter"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-linkedin"></i>
  			</a>
  		</li>
  		
  	</ul>
  </div>
  </nav>
  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container my-5">
    <h1 class="display-4 my-3">Farming Assistant</h1>
    <p class="lead">Farming assistant is a web project to help the farmers working with the motive of greater profitability by direct communication between farmer-to- supplier and farmer-to-farmer. 
This site allows a farmer, retailer and supplier communication.  
It provides an option to farmers and communicates to respective dealers. Farmers are notified whenever dealers publish and advertisement or offer on the website through mobile SMS. 

</p>
  </div>
</div>
</div>

<footer class="text-muted">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      <p>New to Firming Assistant?</p>
      <a href="#">Get Started..</a>
    </div>
  </footer>
<script type="js/bootstrap.min.js"></script>
</body>
</html>