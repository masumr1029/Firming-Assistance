<?php 
  require_once('functions/function.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
</head>
<body>
  <div class="container">
    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <a href="#" class="navbar-brand">
    <i class="fab fa-accusoft"></i>
    Firming Assistant
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="homepage.php" class="nav-link">Home</a>
      </li>
      
      <li class="nav-item">
        <a href="tips.php" class="nav-link">Firming Tips</a>
      </li>
      <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain</a>
          </li>
      <li class="nav-item">
        <a href="contact2.php" class="nav-link" >Contact</a>
      </li>
      
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
      <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
      
    </ul>
  </div>
  </nav>
  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container">
    <?php
            $select="select * from crops";
            $query=mysqli_query($con,$select);
            while ($data=mysqli_fetch_array($query)) {  
          ?>
    <form class="mx-5">

      <a href="view.php?v=<?=$data['crop_id'];?>" class="btn btn-block btn-info my-2"><?=$data['crop_name'];?></a>


    </form>
<?php }?>
  </div>
</div>
</div>

<footer class="text-muted">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      
      <a href="#">Home</a><br>
      <a href="#">Contact</a><br>
      <a href="#">About</a>
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>