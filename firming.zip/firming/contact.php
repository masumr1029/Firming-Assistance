<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script defer src="fontawesome-all.js"></script>
	<script defer src="fa-v4-shims.js"></script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	<a href="#" class="navbar-brand">
		<i class="fab fa-accusoft"></i>
		Firming Assistant
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar">
  	<ul class="navbar-nav">
  		<li class="nav-item">
  			<a href="index.php" class="nav-link">Home</a>
  		</li>
  		<li class="nav-item">
  			<a href="about.php" class="nav-link">About Us</a>
  		</li>
  		<li class="nav-item">
  			<a href="contact.php" class="nav-link">Contact</a>
  		</li>
  		
  	</ul>
  	<ul class="navbar-nav ml-auto">
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-facebook"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-twitter"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fa fa-linkedin"></i>
  			</a>
  		</li>
  		
  	</ul>
  </div>
  </nav>
  <div class="jumbotron jumbotron-fluid ">
  <div class="container ">
    <form>
      <div class="form-group row">
      <label for="inputEmail3" class="mx-2 col-form-label">Name</label>
      <div class="col-sm-5">
        <input type="text" class="form-control mx-5" id="inputEmail3" placeholder="">
      </div>
    </div>
    <div class="form-group row">
      <label for="inputEmail3" class="mx-2 col-form-label">Email</label>
      <div class="col-sm-5">
        <input type="email" class="form-control mx-5" id="inputEmail3" placeholder="">
      </div>
    </div>
    <div class="form-group row">
      <label for="inputEmail3" class="mx-2 col-form-label">Comment</label>
      <div class="col-sm-5">
       <textarea class=" mx-3 form-control"></textarea>
      </div>
    </div>
      <div class="input-group  col-md-6 ">
     <button type="submit" class="btn btn-info ml-auto " name="send">Post</button>
  </div>
    </div>
    </form>
    <pre class="bg-info my-5">
      59/a/1, West Rajabazar
      Tejgaon, Dhaka
      firmingassistant@gmail.com
    </pre>
</div>
  
</div>

<footer class="text-muted">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      <p>New to Firming Assistant?</p>
      <a href="#">Get Started..</a>
    </div>
  </footer>
<script type="js/bootstrap.min.js"></script>
</body>
</html>