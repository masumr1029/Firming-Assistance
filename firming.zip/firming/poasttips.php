<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="adminhome.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="poasttips.php" class="nav-link">Post Tips</a>
          </li>
         

          <li class="nav-item">
            <a href="" class="nav-link">View complain</a>
          </li>

          <li class="nav-item">
            <a href="" class="nav-link">View User List</a>
          </li>
           <li class="nav-item">
            <a href="#" class="nav-link">Add New User</a>
          </li>
      </ul>

    <ul class="navbar-nav ml-auto">

     <!-- <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>-->
      
    </ul>
  </div>
  </nav>

  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container">
    <form>
  <div class="form-group row mx-5 my-3">
    <label  class="col-sm-2 col-form-label">Select Season:</label>
    <div class="col-sm-5">
        <select class="btn btn-block font-weight-bold">
          <option value="">All</option>
          <option value="">Rabi</option>
          <option value="">Kharif-1</option>
          <option value="">Kharif-2</option>
          
        </select>
    </div>
  </div>
  <div class="form-group row mx-5">
    <label  class="col-sm-2 col-form-label">Select Crop:</label>
    <div class="col-sm-5">
        <select class="btn btn-block font-weight-bold">
          <option value="">Paddy</option>
          <option value="">SugarCane</option>
          <option value="">Potato</option>
          <option value="">Corn</option>
          <option value="">Others</option>
        </select>
    </div>
  </div>
  <div class="form-group row mx-5">
    <label  class="col-sm-2 col-form-label ">Select Criteria:</label>
    <div class="col-sm-5">
        <select class="btn btn-block font-weight-bold">
          <option value="">About the Crop</option>
          <option value="">Planting Method</option>
          <option value="">Disease and Treatment</option>
        </select>
    </div>
  </div>
  <div class="form-group row mx-5">
    <label  class="col-sm-2 col-form-label ">Write Tips:</label>
    <div class="col-sm-5">
         <textarea class="form-control py-3 "></textarea>
    </div>
  </div>
  <div class="form-group row col-md-7 ">
    <button type="submit" class="btn btn-info ml-auto ">Post</button>
  </div>
</form>
  </div>
</div>
  
    </div>



<footer class="text-muted">
    <div class="container py-5">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
    
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
</body>
</html>