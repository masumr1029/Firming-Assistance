<?php
    require_once('functions/function.php');

    if(isset($_POST['send'])){
   
    $textarea=$_POST['textarea'];
    $cate_id=$_POST['category'];
    $photo=$_FILES['photo'];

    $ImageName='user-'.time().'-'.md5(rand(10000,100000)).'.'.pathinfo($photo['name'],PATHINFO_EXTENSION);

    // if(empty($textarea)||(empty($cate_id))){
    //   echo"<script>window.alert('please fill up the required fields!!')</script>";
    //   exit();
    //   }
    // else{
    $insert="INSERT INTO post(textarea,cate_id,photo)VALUES('$textarea','$cate_id','$ImageName')";
    $qry=mysqli_query($con,$insert);
    if($qry){
      if($ImageName!=''){
        move_uploaded_file($photo['tmp_name'], 'Uploads/'.$ImageName);
       echo"Product insert succesfull";
       // header('Location: viewall.php');
      }}
      else{
         echo "<script type='text/javascript'>alert('submitted successfully!')</script>";;
        }
    // }
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="homepage.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="homepage.php" class="nav-link">Home</a>
          </li>

          <li class="nav-item">
            <a href="tips.php" class="nav-link">Firming Tips</a>
          </li>
          <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain</a>
          </li>
          
          <li class="nav-item">
           <a href="contact2.php" class="nav-link" >Contact</a>
          </li>
      </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
      <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
      
    </ul>
  </div>
  </nav>

  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container ">

  <form method="post" enctype="multipart/form-data" class="form-inline  py-2 border border-rounded">
    <select name="category" class=" font-weight-bold mx-3 btn btn-info ">
          <option>Select One</option>
          <?php
            $select="select * from post_category";
            $query=mysqli_query($con,$select);
            while ($data=mysqli_fetch_array($query)) {  
          ?>
          <option value="<?=$data['cate_id'];?>"><?=$data['cate_name'];?></option>
          <?php } ?>
        </select>
      <div class="input-group col-md-12 my-2 ">
        <textarea name="textarea" class="form-control py-3 "></textarea>
       </div>

        <div class="input-group col-md-4">
          <label for="exampleInputFile">Upload Image</label>
            <input type="file" name="photo" class="form-control-file" id="exampleInputFile">
    
        </div>
        <div class="input-group col-md-4 text-center">
        
      </div>
  
  <div class="input-group  col-md-4 ">
     <button type="submit" class="btn btn-info ml-auto " name="send">Post</button>
  </div>
  </form>

        <div class="card  my-2 border border border-rounded">
          <?php 
          $select="select * from post order by id desc";
          $query=mysqli_query($con,$select);
          while ($data=mysqli_fetch_array($query)) {
          
          ?>

            <div class="card-body bg-secondary " ">
              <img style=" height:100px;" src="Uploads/<?=$data['photo'];?>">
            </div>
            <div class="card-body bg-secondary">
              <p class="card-text text-white"><?=$data['textarea'];?></p>
          </div>
            <form name="form2" method="post">
              <textarea class="form-control"></textarea>
                <button id="send2" class="btn btn-primary" >Comment</button>
            </form>
          <?php
        }
          ?>

       </div>
       
     
    </div>
  </div>
</div>


<footer class="text-muted">
    <div class="container py-5">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      
      <a href="#">Home</a><br>
      <a href="#">Contact</a><br>
      <a href="#">About</a>
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
</body>
</html>