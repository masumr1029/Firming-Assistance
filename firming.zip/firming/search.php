<?php
    require_once('functions/function.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="home.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="homepage.php" class="nav-link">Home</a>
          </li>

          <li class="nav-item">
            <a href="tips.php" class="nav-link">Firming Tips</a>
          </li>
          <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain</a>
          </li>
          <li class="nav-item">
            <a href="search.php" class="nav-link">Search</a>
          </li>
          <li class="nav-item">
           <a href="contact2.php" class="nav-link" >Contact</a>
          </li>
      </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
      <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
      
    </ul>
  </div>
  </nav>

  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container ">
  <form method="post" enctype="multipart/form-data" class="form-inline  py-2 border border-rounded">
    <select name="category" class=" font-weight-bold mx-3 form-control btn btn-block ">
          <option>Select One</option>
          <?php
            $select="select * from post_category";
            $query=mysqli_query($con,$select);
            while ($data=mysqli_fetch_array($query)) {  
          ?>
          <option value="<?=$data['cate_id'];?>"><?=$data['cate_name'];?></option>
          <?php } ?>
        </select>
     
  
  <div class="input-group  ">
     
     <?php
            if (id==cate_id) {
              
            
            $select="select * from post where cate_id='1'";
            $query=mysqli_query($con,$select);
            while ($data=mysqli_fetch_array($query)) {  
          ?>
        <div class="card-body bg-secondary " ">
              <img style=" height:100px;" src="Uploads/<?=$data['photo'];?>">
            </div>
            <div class="card-body bg-secondary">
              <p class="card-text text-white"><?=$data['textarea'];?></p>
          </div>

          <textarea class="form-control"></textarea>
          <button id="send" class="btn btn-primary ml-auto" >Comment</button>
          <?php
        } }
          ?>

      
  </div>
  </form>

        

       </div>
       
     
    </div>
  </div>
</div>


<footer class="text-muted">
    <div class="container py-5">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      
      <a href="#">Home</a><br>
      <a href="#">Contact</a><br>
      <a href="#">About</a>
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
</body>
</html>