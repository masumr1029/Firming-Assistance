
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="home.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="homepage.php" class="nav-link">Home</a>
          </li>

          <li class="nav-item">
            <a href="tips.php" class="nav-link">Firming Tips</a>
          </li>
          <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain</a>
          </li>
          <li class="nav-item">
           <a href="contact2.php" class="nav-link" >Contact</a>
          </li>
      </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-facebook"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-twitter"></i>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fa fa-linkedin"></i>
        </a>
      </li>
      <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
      
    </ul>
  </div>
  </nav>

  

 <div class="jumbotron jumbotron-fluid ">
  <div class="container ">
     <div class="row mx-5 my-5">
       <a class="bootstrap-link mx-5 col-md-3" href="tips.php"><div class=" text-center">
          <div class="card bg-info text-white" style="height: 200px;">
            <div class="card-body ">
              <h2 class="card-title">View Tips</h2>
                <img class="rounded mx-auto d-block" src="img/farmer.png" style="height: 120px; width: 150px;">
            </div>
      </div>
    </div></a>

    <a class="bootstrap-link mx-3 col-md-3" href="home.php"><div class=" text-center">
          <div class="card bg-info text-white" style="height: 200px;">
            <div class="card-body ">
              <h2 class="card-title">Share Post</h2>
                <img class="rounded mx-auto d-block" src="img/farm.png" style="height: 120px; width: 150px;">
            </div>
      </div>
    </div></a>

    <a class="bootstrap-link mx-3 col-md-3" href="complain.php"><div class=" text-center">
          <div class="card bg-info text-white" style="height: 200px;">
            <div class="card-body ">
              <h2 class="card-title">Problem/<br>Complain</h2>
                <img class="rounded mx-auto d-block" src="img/farmer-hi.png" style="height: 80px; width: 100px;">
            </div>
      </div>
    </div></a>
     </div>
    </div>
  </div>
</div>


<footer class="text-muted">
    <div class="container py-5">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      
      <a href="#">Home</a><br>
      <a href="#">Contact</a><br>
      <a href="#">About</a>
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
</body>
</html>