<?php
	$con=mysqli_connect("localhost","root","","farmer");
	if(!$con){
		echo "connection error";
		}
?>
