<?php
 require_once('functions/function.php');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
</head>
<body>
  <div class="container">
    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <a href="index.php" class="navbar-brand">
    <i class="fab fa-accusoft"></i>
    Firming Assistant
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  </nav>
<div class="jumbotron ">
  <div class="row">
    <div class="col-md-5 text-center">
      <div class="card bg-primary text-white" style="box-shadow: 5px 5px 5px 5px #aaaaaa;">
        <div class="card-body ">
          <h2 class="card-title">Firming Assistant</h2>
          <p class="lead">Join, Contact, Share and Help</p>
        </div>
      </div>
    </div>
    <div class="col-md-5 offset-md-1 ">
      <div class="card" style="box-shadow: 0px 2px 2px 2px #aaaaaa;">
        <div class="card-body">
          
            <h4 class="text-center bold">Admin Login</h4>

<?php
                        if(isset($_POST['Send'])){
                        $name=$_POST['username'];
                        $password=md5($_POST['password']);
                    $sel="SELECT * FROM admin WHERE username='$name' AND password='$password'";
                        $qry=mysqli_query($con, $sel);
                        $res=mysqli_fetch_array($qry);
                        if($res){
                          $_SESSION['name']=$res['name'];
                          $_SESSION['user']=$res['username'];
                          $_SESSION['last_time']=time();

                          header('location: home.php');
                        }else{
                          echo "Username and Password incorrect!!!";
                          }
                        }
        ?>
        <form method="post">
            <!--form start-->
              <div class="form-group">
              <div class="d-flex">
                <span class="pr-3">
                  <i class="fas fa-user-circle fa-2x"></i>
                </span>
                <input type="text" name="username" class="form-control" placeholder="User Name" required="">
              </div>
            </div>
           
            <div class="form-group">
              <div class="d-flex">
                <span class="pr-3">
                  <i class="fas fa-unlock fa-2x"></i>
                </span>
                <input type="password" name="password" class="form-control" placeholder="Password" required="">
              </div>
            </div>
            <div class="d-flex justify-content-center">
              <button type="submit" name="Send" class="btn btn-primary ">Login</button>
             
            </div>

            
          </form>
          <!--end form-->
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<footer class="text-muted py-5">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      <p>New to Firming Assistant?</p>
      <a href="#">Get Started..</a>
    </div>
  </footer>
<script type="js/bootstrap.min.js"></script>
</body>
</html>