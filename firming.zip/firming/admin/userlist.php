<?php
 require_once('functions/function.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a href="home.php" class="navbar-brand">
          <i class="fab fa-accusoft"></i>
          Firming Assistant
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userlist.php" class="nav-link">User List</a>
          </li>

          <li class="nav-item">
            <a href="tips.php" class="nav-link">Firming Tips</a>
          </li>
          <li class="nav-item">
            <a href="complain.php" class="nav-link">Complain/Suggestion</a>
          </li>
      </ul>
          <ul class="ml-auto">
            <button class="btn btn-primary btn-sm " onclick="window.location.href='logout.php'">Logout</button>
          </ul>
  </div>
  </nav>

  
  
 <div class="jumbotron jumbotron-fluid ">
  <div class="container ">
 
       <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Phone</th>
      <th scope="col">User Name</th>
      
    </tr>
  </thead>
  <tbody>
     <?php
            $select="select * from users order by id asc";
            $query=mysqli_query($con,$select);
            while ($data=mysqli_fetch_array($query)) {  
          ?>
    <tr>
      <!-- <th scope="row"></th> -->
      <td><?=$data['id'];?></td>
      <td><?=$data['phone'];?></td>
      <td><?=$data['username'];?></td>
      <td><a class="btn btn-danger" href="delete.php?d=<?=$data['id'];?>">Delete</a></td>
    </tr>
    <?php }?>
    
  </tbody>

</table>
    
    </div>
  </div>
</div>


<footer class="text-muted">
    <div class="container py-5">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      
      <a href="home.php">Home</a><br>
      
    </div>
  </footer>
<script type="js/bootstrap.bundle.min.js"></script>
</body>
</html>