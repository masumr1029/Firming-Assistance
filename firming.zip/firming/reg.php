<?php
    require_once('functions/function.php');

    if(isset($_POST['send'])){
   
    $phone=$_POST['phone'];
    $username=$_POST['username'];
    $password=md5($_POST['password']);
    // $photo=$_FILES['photo'];
    // $ImageName='user-'.time().'-'.md5(rand(10000,100000)).'.'.pathinfo($photo['name'],PATHINFO_EXTENSION);

    if(empty($phone)||(empty($password))){
      echo"<script>window.alert('please fill up the required fields!!')</script>";
      exit();
      }
    else{
    $insert="INSERT INTO users(phone,username,password)VALUES('$phone','$username','$password')";
    $qry=mysqli_query($con,$insert);
    if($qry){
       header('Location: login.php');
      }
      else{
         echo"window.alert('Product insert Failed!!')";
        }
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script defer src="fontawesome-all.js"></script>
  <script defer src="fa-v4-shims.js"></script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	<a href="index.php" class="navbar-brand">
		<i class="fab fa-accusoft"></i>
		Firming Assistant
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar">
  	<ul class="navbar-nav">
  		<li class="nav-item">
  			<a href="index.php" class="nav-link">Home</a>
  		</li>
  		<li class="nav-item">
  			<a href="about.php" class="nav-link">About Us</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">Contact</a>
  		</li>
  		
  	</ul>
  	<ul class="navbar-nav ml-auto">
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fab fa-facebook"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fab fa-twitter"></i>
  			</a>
  		</li>
  		<li class="nav-item">
  			<a href="#" class="nav-link">
  				<i class="fab fa-linkedin"></i>
  			</a>
  		</li>
  		
  	</ul>
  </div>
  </nav>
<div class="jumbotron ">
  <div class="row">
    <div class="col-md-5 text-center">
      <div class="card bg-primary text-white" style="box-shadow: 5px 5px 5px 5px #aaaaaa;">
        <div class="card-body ">
          <h2 class="card-title">Firming Assistant</h2>
          <p class="lead">Join, Contact, Share and Help</p>
        </div>
      </div>
    </div>
    <div class="col-md-5 offset-md-1 ">
      <div class="card" style="box-shadow: 0px 2px 2px 2px #aaaaaa;">
        <div class="card-body">
          <form method="post" >
            <h4 class="text-center bold">Register Now</h4>

            <!--Reg form start here-->
              <div class="form-group">
              <div class="d-flex">
                <span class="pr-3">
                  <i class="fas fa-user-circle fa-2x"></i>
                </span>
                <input type="text" name="username" class="form-control" placeholder="User Name" required=""> 
              </div>
              </div>
              <div class="form-group">
                <div class="d-flex">
                <span class="pr-3">
                  <i class="fas fa-phone fa-2x"></i>
                </span>
                <input type="text" name="phone" class="form-control" placeholder="Phone" required="">
              </div>
              </div>
              
            <div class="form-group">
              <div class="d-flex">
                <span class="pr-3">
                  <i class="fas fa-unlock fa-2x"></i>
                </span>
                <input type="password" name="password" class="form-control" placeholder="Password" required="">
              </div>
            </div>
            <div class="d-flex justify-content-center">
              <button type="submit" name="send" class="btn btn-primary  ">Sign Up</button>
              &nbsp &nbsp &nbsp &nbsp<a href="login.php" class="text-center">Already a Member?</a>

            </div>
            
          
          </form>
          <!--end of reg form-->

        </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<footer class="text-muted">
    <div class="container py-3">
      <div class="float-right">
        <p>&copyMasum Rana</p>
      </div>
      <p>New to Firming Assistant?</p>
      <a href="#">Get Started..</a>
    </div>
  </footer>
<script type="js/bootstrap.min.js"></script>
</body>
</html>